// src/components/TaskCard.jsx
import React from 'react';
import { Draggable } from '@hello-pangea/dnd';
import './Kanban.css';

function TaskCard({ task, index, onDelete }) {
  return (
    <Draggable draggableId={task.$id} index={index}>
      {(provided) => (
        <div
          className="task-card"
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
        >
          <h4>{task.title}</h4>
          <p>{task.description}</p>
          <p><strong></strong> {task.date}</p>
          <p><strong>👤</strong> {task.createdBy}</p>

          {task.assignedTo && (
            <p><strong>Assigned to:</strong> {task.assignedTo}</p>
          )}

          <button className="delete-btn" onClick={() => onDelete(task.$id)}>Delete</button>
        </div>
      )}
    </Draggable>
  );
}

export default TaskCard;
