import { Client, Users } from 'node-appwrite';

export default async ({ req, res }) => {
  const client = new Client()
    .setEndpoint(process.env.APPWRITE_ENDPOINT)
    .setProject(process.env.APPWRITE_FUNCTION_PROJECT_ID)
    .setKey(process.env.APPWRITE_API_KEY);

  const users = new Users(client);

  try {
    const result = await users.list();
    console.log("📢 Raw Users Response:", result); // Debugging

    return res.json({
      users: (result.users || []).map(user => ({
        id: user.$id,
        name: user.name || "No Name",
        email: user.email || "No Email"
      }))
    });
  } catch (error) {
    console.error('❌ Error listing users:', error);
    return res.send(`Failed to fetch users: ${error.message}`, 500);
  }
};
