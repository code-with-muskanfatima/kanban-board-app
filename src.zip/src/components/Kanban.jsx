// src/components/Kanban.jsx
import React, { useEffect, useState } from 'react';
import { DragDropContext } from '@hello-pangea/dnd';
import KanbanColumn from './Column';
import { databases, ID, DATABASE_ID, COLLECTION_ID } from '../appwriteConfig';
import './Kanban.css';

const DEFAULT_TASKS = [
  {
    title: 'Build Portfolio Website',
    description: 'Create a professional portfolio using React and Tailwind.',
    date: '2025-07-10',
    tags: ['portfolio', 'frontend'],
    image: 'https://source.unsplash.com/random/40x40?web',
    links: [
      'https://github.com/your-repo',
      'https://linkedin.com/in/yourprofile',
      'https://figma.com/file/sample',
    ],
    status: 'todo',
  },
  {
    title: 'Design Landing Page',
    description: 'Mock a landing page with Figma and implement it.',
    date: '2025-07-10',
    tags: ['design', 'ui'],
    image: 'https://source.unsplash.com/random/40x40?design',
    links: [
      'https://github.com/sample-landing',
      'https://linkedin.com/in/designer',
      'https://figma.com/file/landing',
    ],
    status: 'in-progress',
  },
];

function Kanban() {
  const [columns, setColumns] = useState({
    todo: { name: 'To Do', tasks: [] },
    'in-progress': { name: 'In Progress', tasks: [] },
    done: { name: 'Done', tasks: [] },
  });

  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    tags: '',
    date: '',
    description: '',
    image: '',
    column: 'todo',
  });

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const res = await databases.listDocuments(DATABASE_ID, COLLECTION_ID);
        const newColumns = {
          todo: { name: 'To Do', tasks: [] },
          'in-progress': { name: 'In Progress', tasks: [] },
          done: { name: 'Done', tasks: [] },
        };

        if (res.total === 0) {
          for (const task of DEFAULT_TASKS) {
            await databases.createDocument(
              DATABASE_ID,
              COLLECTION_ID,
              ID.unique(),
              task
            );
          }

          // Fetch again after creating
          const updatedRes = await databases.listDocuments(DATABASE_ID, COLLECTION_ID);
          updatedRes.documents.forEach((doc) => {
            if (newColumns[doc.status]) {
              newColumns[doc.status].tasks.push({ ...doc });
            }
          });
        } else {
          res.documents.forEach((doc) => {
            if (newColumns[doc.status]) {
              newColumns[doc.status].tasks.push({ ...doc });
            }
          });
        }

        setColumns(newColumns);
      } catch (err) {
        console.error('Error fetching tasks:', err);
      }
    };
    fetchTasks();
  }, []);

  const handleDragEnd = async ({ source, destination }) => {
    if (!destination) return;
    if (source.droppableId === destination.droppableId && source.index === destination.index) return;

    const sourceCol = columns[source.droppableId];
    const destCol = columns[destination.droppableId];
    const [movedTask] = sourceCol.tasks.splice(source.index, 1);
    destCol.tasks.splice(destination.index, 0, movedTask);

    setColumns({ ...columns });

    try {
      await databases.updateDocument(DATABASE_ID, COLLECTION_ID, movedTask.$id, {
        status: destination.droppableId,
      });
    } catch (err) {
      console.error('Failed to update status in Appwrite:', err);
    }
  };

  const openModal = (colId) => {
    setFormData({ title: '', tags: '', date: '', description: '', image: '', column: colId });
    setShowModal(true);
  };

  const handleInput = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const createTask = async () => {
    if (!formData.title || !formData.date) return;

    const newTask = {
      title: formData.title,
      description: formData.description || '',
      date: formData.date,
      tags: formData.tags ? formData.tags.split(',').map((t) => t.trim()) : [],
      image: formData.image || 'https://source.unsplash.com/random/40x40?task',
      links: [
        'https://github.com/example',
        'https://linkedin.com/in/example',
        'https://figma.com/file/example',
      ],
      status: formData.column,
    };

    try {
      const res = await databases.createDocument(
        DATABASE_ID,
        COLLECTION_ID,
        ID.unique(),
        newTask
      );
      setColumns((prev) => ({
        ...prev,
        [formData.column]: {
          ...prev[formData.column],
          tasks: [res, ...prev[formData.column].tasks],
        },
      }));
    } catch (err) {
      console.error('Error creating task:', err);
    }
    setShowModal(false);
  };

  const handleDelete = async (taskId, columnId) => {
    setColumns((prev) => {
      const newTasks = prev[columnId].tasks.filter(task => task.$id !== taskId);
      return {
        ...prev,
        [columnId]: {
          ...prev[columnId],
          tasks: newTasks,
        },
      };
    });

    try {
      await databases.deleteDocument(DATABASE_ID, COLLECTION_ID, taskId);
      console.log("✅ Task deleted from Appwrite");
    } catch (error) {
      console.error("❌ Failed to delete from Appwrite:", error);
    }
  };

  return (
    <div className="kanban-wrapper">
      <h1 className="kanban-title">Kanban board ⭐</h1>
      <DragDropContext onDragEnd={handleDragEnd}>
        <div className="board">
          {Object.entries(columns).map(([colId, col]) => (
            <KanbanColumn
              key={colId}
              columnId={colId}
              title={col.name}
              tasks={col.tasks}
              openModal={openModal}
              onDelete={handleDelete}
            />
          ))}
        </div>
      </DragDropContext>

      {showModal && (
        <div className="modal-backdrop">
          <div className="modal">
            <h3>Create New Task</h3>
            <input type="text" name="title" value={formData.title} onChange={handleInput} placeholder="Task Title" />
            <input type="text" name="description" value={formData.description} onChange={handleInput} placeholder="Description" />
            <input type="text" name="tags" value={formData.tags} onChange={handleInput} placeholder="Tags (comma separated)" />
            <input type="date" name="date" value={formData.date} onChange={handleInput} />
            <input type="text" name="image" value={formData.image} onChange={handleInput} placeholder="Image URL (optional)" />
            <div className="modal-buttons">
              <button onClick={(e) => {
                e.preventDefault();
                createTask();
              }}>Create</button>
              <button className="cancel-btn" onClick={() => setShowModal(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Kanban;
