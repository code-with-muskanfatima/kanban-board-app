import React from 'react';
import { Draggable } from '@hello-pangea/dnd';
import { Trash2, Github, Linkedin, Figma } from 'lucide-react';

function TaskCard({ task, index, onDelete, columnId }) {
  return (
    <Draggable draggableId={task.$id || task.id} index={index}>
      {(provided) => (
        <div
          className="task-card"
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
          style={{
            padding: '1rem',
            background: '#fff',
            borderRadius: '0.75rem',
            boxShadow: '0 2px 5px rgba(0,0,0,0.1)',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.5rem',
            ...provided.draggableProps.style,
          }}
        >
          {/* Body: Image + Title/Description */}
          <div className="task-card-body" style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <img src={task.image} className="avatar" />
            <div className="task-content">
              <h4 style={{ margin: 0 }}>{task.title}</h4>
              <p style={{ margin: 0, fontSize: '0.9rem', color: '#555' }}>{task.description}</p>
              <p style={{ margin: 0, fontSize: '0.8rem', color: '#888' }}>{task.date}</p>
            </div>
          </div>

          {/* Bottom: Links + Delete */}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              {Array.isArray(task.links) && task.links.map((link, i) => {
                if (link.includes('github.com')) {
                  return (
                    <a key={i} href={link} target="_blank" rel="noreferrer">
                      <Github size={16} color="#000" />
                    </a>
                  );
                } else if (link.includes('linkedin.com')) {
                  return (
                    <a key={i} href={link} target="_blank" rel="noreferrer">
                      <Linkedin size={16} color="#0a66c2" />
                    </a>
                  );
                } else if (link.includes('figma.com')) {
                  return (
                    <a key={i} href={link} target="_blank" rel="noreferrer">
                      <Figma size={16} color="#a259ff" />
                    </a>
                  );
                } else {
                  return null;
                }
              })}
            </div>
            <button
              onClick={() => onDelete(task.$id || task.id, columnId)}
              style={{
                background: 'none',
                border: 'none',
                cursor: 'pointer',
              }}
              title="Delete Task"
            >
              <Trash2 size={16} color="#e74c3c" />
            </button>
          </div>
        </div>
      )}
    </Draggable>
  );
}

export default TaskCard;
